# Database Tables

## products
Stores product catalog, price, offer price, stock, images.

## customers
Stores customer by WhatsApp number. No password needed.

## orders
Stores each customer order.

## order_items
Stores products inside each order.

## reward_rules
Stores reward rules:
- 500 = Chicken Roll
- 1000 = 1kg Puttu
- 2000 = Chicken Biryani
- 3000 = Gingelly Oil

## reward_claims
Stores what free gifts customer claimed.

## stock_movements
Tracks stock changes.