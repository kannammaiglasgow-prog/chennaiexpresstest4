-- CHENNAI EXPRESS BACKEND PHASE 1
-- Supabase PostgreSQL schema

create extension if not exists "uuid-ossp";

-- 1. Products
create table if not exists products (
  id uuid primary key default uuid_generate_v4(),
  sku text unique,
  name text not null,
  category text not null,
  subcategory text,
  description text,
  price numeric(10,2) not null default 0,
  offer_price numeric(10,2),
  pack_size text,
  image_url text,
  stock_status text not null default 'in_stock', -- in_stock / out_of_stock / low_stock
  stock_qty integer default 0,
  is_best_seller boolean default false,
  is_special_offer boolean default false,
  is_active boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 2. Customers by WhatsApp number, no password/login needed
create table if not exists customers (
  id uuid primary key default uuid_generate_v4(),
  name text,
  whatsapp_number text unique not null,
  total_orders integer default 0,
  total_spend numeric(10,2) default 0,
  reward_points integer default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 3. Orders
create table if not exists orders (
  id uuid primary key default uuid_generate_v4(),
  order_id text unique not null,
  customer_id uuid references customers(id),
  customer_name text not null,
  whatsapp_number text not null,
  order_type text not null, -- Collection / Delivery
  delivery_address text,
  postcode text,
  payment_method text,
  subtotal numeric(10,2) default 0,
  delivery_charge numeric(10,2) default 0,
  total numeric(10,2) default 0,
  reward_points_earned integer default 0,
  reward_points_used integer default 0,
  reward_points_remaining integer default 0,
  status text default 'pending', -- pending / edited / confirmed / preparing / ready / completed / cancelled
  collection_date date,
  collection_time time,
  delivery_date date,
  delivery_time time,
  admin_note text,
  customer_note text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- 4. Order Items
create table if not exists order_items (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid references orders(id) on delete cascade,
  product_id uuid references products(id),
  product_name text not null,
  quantity integer not null default 1,
  unit_price numeric(10,2) default 0,
  line_total numeric(10,2) default 0,
  status text default 'available', -- available / out_of_stock / removed / replaced
  created_at timestamptz default now()
);

-- 5. Reward Rules
create table if not exists reward_rules (
  id uuid primary key default uuid_generate_v4(),
  points_required integer not null,
  reward_name text not null,
  reward_description text,
  image_url text,
  is_active boolean default true,
  created_at timestamptz default now()
);

-- 6. Reward Claims
create table if not exists reward_claims (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid references orders(id) on delete cascade,
  customer_id uuid references customers(id),
  reward_rule_id uuid references reward_rules(id),
  reward_name text not null,
  points_used integer not null,
  status text default 'claimed',
  created_at timestamptz default now()
);

-- 7. Stock Movements
create table if not exists stock_movements (
  id uuid primary key default uuid_generate_v4(),
  product_id uuid references products(id),
  movement_type text not null, -- add / reduce / adjustment / out_of_stock
  quantity integer default 0,
  note text,
  created_at timestamptz default now()
);

-- Default reward rules
insert into reward_rules (points_required, reward_name, reward_description)
values
(500, 'Free Chicken Roll', 'Customer can claim free Chicken Roll'),
(1000, 'Free 1kg Puttu', 'Customer can claim free 1kg Puttu'),
(2000, 'Free Chicken Biryani', 'Customer can claim free Chicken Biryani'),
(3000, 'Free Gingelly Oil', 'Customer can claim free Gingelly Oil')
on conflict do nothing;

-- Useful views

create or replace view admin_today_orders as
select
  order_id,
  customer_name,
  whatsapp_number,
  order_type,
  total,
  status,
  created_at
from orders
where created_at::date = current_date
order by created_at desc;

create or replace view low_stock_products as
select
  sku,
  name,
  category,
  stock_qty,
  stock_status
from products
where stock_status in ('low_stock','out_of_stock') or stock_qty <= 5
order by stock_qty asc;

-- Row Level Security notes:
-- For production, enable RLS and allow only admin role to write.

-- V5 Product Save Support Fields
alter table products add column if not exists allergy_information text;
alter table products add column if not exists ingredients text;
alter table products add column if not exists is_vegetarian text;
alter table products add column if not exists is_halal text;

-- Prototype policies for browser admin.
-- For production, replace these with secure admin login policies.
alter table products enable row level security;

drop policy if exists "public read products" on products;
create policy "public read products"
on products for select
using (true);

drop policy if exists "prototype insert products" on products;
create policy "prototype insert products"
on products for insert
with check (true);

drop policy if exists "prototype update products" on products;
create policy "prototype update products"
on products for update
using (true)
with check (true);

drop policy if exists "prototype delete products" on products;
create policy "prototype delete products"
on products for delete
using (true);

-- Storage bucket setup:
-- This creates the public product image bucket and prototype-friendly
-- browser upload policies used by admin/admin.js.
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do update set public = true;

drop policy if exists "public read product images" on storage.objects;
create policy "public read product images"
on storage.objects for select
using (bucket_id = 'product-images');

drop policy if exists "prototype upload product images" on storage.objects;
create policy "prototype upload product images"
on storage.objects for insert
with check (bucket_id = 'product-images');

drop policy if exists "prototype update product images" on storage.objects;
create policy "prototype update product images"
on storage.objects for update
using (bucket_id = 'product-images')
with check (bucket_id = 'product-images');

drop policy if exists "prototype delete product images" on storage.objects;
create policy "prototype delete product images"
on storage.objects for delete
using (bucket_id = 'product-images');
