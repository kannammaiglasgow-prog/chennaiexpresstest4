# Admin Workflow

## Order Flow

Customer places order from frontend
↓
Order appears in admin dashboard
↓
Admin checks products and stock
↓
If item is unavailable:
- Remove item
- Mark item out of stock
- Send updated invoice to customer

If all items are available:
- Confirm order
- Add collection/delivery time
- Send confirmation to customer

## Stock Flow

Product stock can be:

- In Stock
- Low Stock
- Out of Stock

When stock becomes 0, frontend should show Out of Stock.

## Rewards Flow

Customer does not need login.

WhatsApp number = customer identity.

Example:
447309xxxxxx
↓
Reward points
↓
Order history
↓
Free gifts