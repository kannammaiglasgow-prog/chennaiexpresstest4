-- Sample products for testing

insert into products
(sku, name, category, subcategory, description, price, offer_price, pack_size, stock_status, stock_qty, is_best_seller, is_special_offer)
values
('CE-FOOD-001', 'Chicken Biryani', 'Restaurant Food', 'Biryani', 'Fresh chicken biryani', 8.99, null, '1 Portion', 'in_stock', 50, true, false),
('CE-FOOD-002', 'Chicken Roll', 'Restaurant Food', 'Snacks', 'Sri Lankan style chicken roll', 1.50, null, '1 pc', 'in_stock', 100, true, false),
('CE-FOOD-003', '1kg Puttu', 'Restaurant Food', 'Ready To Eat', 'Fresh 1kg puttu', 9.99, null, '1kg', 'in_stock', 20, true, false),
('CE-GROC-001', 'Gingelly Oil 1L', 'Grocery', 'Oil & Ghee', 'Sesame gingelly oil', 8.99, 5.99, '1L', 'in_stock', 30, false, true),
('CE-GROC-002', 'Necto Mango Drink', 'Grocery', 'Drinks', 'Mango drink', 1.49, null, '750ml', 'in_stock', 80, false, false)
on conflict (sku) do nothing;